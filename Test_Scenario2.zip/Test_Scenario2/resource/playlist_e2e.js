//Mobile UI Automated Tests
require('../test/deriv_calculation_test')
